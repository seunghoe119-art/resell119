import { WorkLogDashboard } from "@/components/work-log-dashboard"

export default function Page() {
  return <WorkLogDashboard />
}
