"use client"

import { useState } from "react"
import { ChevronLeft, ChevronRight, Calendar, Sparkles, Search, FileText, BookOpen } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader } from "@/components/ui/card"
import { Textarea } from "@/components/ui/textarea"
import { cn } from "@/lib/utils"

interface WorkLogEntry {
  id: number
  time: string
  content: string
  aiOptimized: string
  note: string
}

const sampleData: WorkLogEntry[] = [
  {
    id: 1,
    time: "09:00",
    content: "팀 미팅 참석 및 주간 업무 브리핑 진행",
    aiOptimized: "",
    note: "화상회의",
  },
  {
    id: 2,
    time: "10:30",
    content: "Q2 전략 기획안 초안 작성 및 검토",
    aiOptimized: "",
    note: "",
  },
  {
    id: 3,
    time: "13:00",
    content: "고객사 A사 미팅 - 신규 프로젝트 논의",
    aiOptimized: "",
    note: "강남 오피스",
  },
  {
    id: 4,
    time: "15:30",
    content: "프로젝트 진행 현황 문서 업데이트",
    aiOptimized: "",
    note: "",
  },
  {
    id: 5,
    time: "17:00",
    content: "부서 내 업무 조율 및 일정 확인",
    aiOptimized: "",
    note: "",
  },
]

const secretReferences = [
  "참고 문헌 1: 기업 전략 기획 가이드라인 (2026 개정판)",
  "참고 문헌 2: 내부 프로젝트 관리 매뉴얼 v3.2",
  "참고 문헌 3: 고객 커뮤니케이션 프로토콜",
  "참고 문헌 4: 보안 정책 및 데이터 취급 지침",
  "비밀 메모: 다음 분기 인사 이동 관련 참고사항",
  "내부용: 경쟁사 분석 자료 링크 - 외부 공유 금지",
]

export function WorkLogDashboard() {
  const [currentDate, setCurrentDate] = useState(new Date())
  const [activeTab, setActiveTab] = useState<"worklog" | "reference">("worklog")
  const [entries, setEntries] = useState<WorkLogEntry[]>(sampleData)
  const [currentPage, setCurrentPage] = useState(1)
  const [tomorrowPlan, setTomorrowPlan] = useState("")
  const [freeMemo, setFreeMemo] = useState("")

  const formatDate = (date: Date) => {
    const year = date.getFullYear()
    const month = String(date.getMonth() + 1).padStart(2, "0")
    const day = String(date.getDate()).padStart(2, "0")
    return `${year}-${month}-${day}`
  }

  const getDayOfWeek = (date: Date) => {
    const days = ["일요일", "월요일", "화요일", "수요일", "목요일", "금요일", "토요일"]
    return days[date.getDay()]
  }

  const navigateDate = (direction: "prev" | "next") => {
    const newDate = new Date(currentDate)
    newDate.setDate(newDate.getDate() + (direction === "next" ? 1 : -1))
    setCurrentDate(newDate)
  }

  const handleAiOptimize = (id: number) => {
    setEntries((prev) =>
      prev.map((entry) =>
        entry.id === id
          ? {
              ...entry,
              aiOptimized:
                entry.aiOptimized ||
                `[AI 최적화] ${entry.content.slice(0, 20)}... - 핵심 업무 요약 및 성과 지표 분석 완료`,
            }
          : entry
      )
    )
  }

  return (
    <div className="min-h-screen bg-background p-4 md:p-6 lg:p-8">
      <div className="mx-auto max-w-7xl">
        {/* Tabs */}
        <div className="mb-6 flex items-center gap-1 border-b border-border">
          <button
            onClick={() => setActiveTab("worklog")}
            className={cn(
              "flex items-center gap-2 px-4 py-3 text-sm font-medium transition-colors",
              activeTab === "worklog"
                ? "border-b-2 border-primary text-primary"
                : "text-muted-foreground hover:text-foreground"
            )}
          >
            <FileText className="h-4 w-4" />
            업무 일지
          </button>
          <button
            onClick={() => setActiveTab("reference")}
            className={cn(
              "flex items-center gap-2 px-4 py-3 text-sm font-medium transition-colors",
              activeTab === "reference"
                ? "border-b-2 border-primary text-primary"
                : "text-muted-foreground hover:text-foreground"
            )}
          >
            <BookOpen className="h-4 w-4" />
            참고 문헌
          </button>
        </div>

        {activeTab === "worklog" ? (
          <>
            {/* Header */}
            <Card className="mb-6">
              <CardContent className="flex flex-col gap-4 p-4 md:flex-row md:items-center md:justify-between">
                {/* Date Navigation */}
                <div className="flex items-center gap-3">
                  <Button
                    variant="outline"
                    size="icon"
                    onClick={() => navigateDate("prev")}
                    className="h-9 w-9"
                  >
                    <ChevronLeft className="h-4 w-4" />
                  </Button>

                  <div className="flex items-center gap-2">
                    <Calendar className="h-5 w-5 text-primary" />
                    <span className="text-lg font-semibold text-foreground">
                      {formatDate(currentDate)}
                    </span>
                    <span className="text-sm text-muted-foreground">({getDayOfWeek(currentDate)})</span>
                  </div>

                  <Button
                    variant="outline"
                    size="icon"
                    onClick={() => navigateDate("next")}
                    className="h-9 w-9"
                  >
                    <ChevronRight className="h-4 w-4" />
                  </Button>
                </div>

                {/* Author Info */}
                <div className="flex items-center gap-4 text-sm">
                  <div className="flex items-center gap-2">
                    <span className="text-muted-foreground">작성자:</span>
                    <span className="font-medium text-foreground">이화민</span>
                  </div>
                  <div className="h-4 w-px bg-border" />
                  <div className="flex items-center gap-2">
                    <span className="text-muted-foreground">소속:</span>
                    <span className="font-medium text-foreground">전략기획팀</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Main Table */}
            <Card className="mb-6">
              <CardHeader className="border-b border-border bg-secondary/50 px-4 py-3">
                <h2 className="text-base font-semibold text-foreground">업무 기록</h2>
              </CardHeader>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-border bg-muted/30">
                      <th className="w-24 px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                        기록 시각
                      </th>
                      <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                        업무 상세 내용
                      </th>
                      <th className="w-64 px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                        AI 최적화
                      </th>
                      <th className="w-32 px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                        비고
                      </th>
                      <th className="w-24 px-4 py-3 text-center text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                        액션
                      </th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-border">
                    {entries.map((entry) => (
                      <tr key={entry.id} className="transition-colors hover:bg-muted/20">
                        <td className="whitespace-nowrap px-4 py-4 text-sm font-medium text-primary">
                          {entry.time}
                        </td>
                        <td className="px-4 py-4 text-sm text-foreground">{entry.content}</td>
                        <td className="px-4 py-4 text-sm text-muted-foreground">
                          {entry.aiOptimized || (
                            <span className="italic text-muted-foreground/50">AI 정리 대기 중...</span>
                          )}
                        </td>
                        <td className="px-4 py-4 text-sm text-muted-foreground">{entry.note}</td>
                        <td className="px-4 py-4 text-center">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleAiOptimize(entry.id)}
                            className="gap-1.5 text-xs"
                          >
                            <Sparkles className="h-3.5 w-3.5" />
                            AI 정리
                          </Button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </Card>

            {/* Bottom Section */}
            <div className="mb-6 grid gap-6 md:grid-cols-2">
              <Card>
                <CardHeader className="border-b border-border bg-secondary/50 px-4 py-3">
                  <h3 className="text-sm font-semibold text-foreground">내일 업무 계획</h3>
                </CardHeader>
                <CardContent className="p-4">
                  <Textarea
                    placeholder="내일 예정된 업무를 작성하세요..."
                    value={tomorrowPlan}
                    onChange={(e) => setTomorrowPlan(e.target.value)}
                    className="min-h-32 resize-none"
                  />
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="border-b border-border bg-secondary/50 px-4 py-3">
                  <h3 className="text-sm font-semibold text-foreground">자유 메모</h3>
                </CardHeader>
                <CardContent className="p-4">
                  <Textarea
                    placeholder="기타 메모 사항을 작성하세요..."
                    value={freeMemo}
                    onChange={(e) => setFreeMemo(e.target.value)}
                    className="min-h-32 resize-none"
                  />
                </CardContent>
              </Card>
            </div>

            {/* Pagination */}
            <Card>
              <CardContent className="flex flex-col items-center justify-between gap-4 p-4 sm:flex-row">
                <div className="flex items-center gap-2">
                  {[1, 2, 3, 4, 5].map((page) => (
                    <Button
                      key={page}
                      variant={currentPage === page ? "default" : "outline"}
                      size="sm"
                      onClick={() => setCurrentPage(page)}
                      className="h-8 w-8 p-0"
                    >
                      {page}
                    </Button>
                  ))}
                  <span className="ml-2 text-sm text-muted-foreground">...</span>
                </div>

                <Button variant="outline" className="gap-2">
                  <Search className="h-4 w-4" />
                  날짜로 검색
                </Button>
              </CardContent>
            </Card>
          </>
        ) : (
          /* Reference Tab - Secret Content */
          <Card>
            <CardHeader className="border-b border-border bg-secondary/50 px-4 py-3">
              <h2 className="text-base font-semibold text-foreground">참고 문헌 (Reference)</h2>
              <p className="mt-1 text-xs text-muted-foreground">
                * 내용을 확인하려면 아래 영역을 마우스로 드래그하세요
              </p>
            </CardHeader>
            <CardContent className="p-6">
              <div className="space-y-4 rounded-lg border border-border bg-white p-6">
                {secretReferences.map((ref, index) => (
                  <p key={index} className="secret-text text-sm leading-relaxed">
                    {ref}
                  </p>
                ))}
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  )
}
